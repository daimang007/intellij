import json
import requests
from tqdm import tqdm
import time

# create faiss index
class CreateFaissIndex:
    
    def __init__(self):
        self.faiss_url = "http://0.0.0.0:9225/create"
        
    def combine_data(self, filename_list):
        
        total_passage_list = list()
        for filename in filename_list:
            filepath = f"/home/ec2-user/workspace/data/hana_data/{filename}"
            with open(filepath,"r") as f:
                load_data = json.load(f)
            total_passage_list.append(load_data)
            
        return total_passage_list
    
    def transform_data(self, original_data_list):
        final_passage_list = list()
        for doc_data in original_data_list:
            doc_id = doc_data["doc_id"]
            doc_title = doc_data["doc_title"]
            
            article_outputs = list()
            for contents in tqdm(doc_data["doc_contents"]):
                sub_id = contents["sub_id"]
                sub_title = contents["sub_title"]
                
                for article in contents["article_datas"]:
                    data_dict = {"doc_id":doc_id, 
                                "doc_title":doc_title,
                                "file_path" : "None",
                                "sub_data":[{"sub_id":sub_id,
                                            "sub_title":sub_title,
                                            "article_data":[article]}]}
                    
                    article_outputs.append(data_dict)
                    
            final_passage_list.extend(article_outputs)
        
        save_data = {"article_outputs":final_passage_list}
        
        with open("/home/ec2-user/workspace/data/hana_data/elasticsearch_hana_passage.json","w", encoding="utf-8") as f:
            json.dump(save_data, f, ensure_ascii=False, indent=4)
        
        return save_data
    
    def create_faiss_index(self):
        
        with open("/home/ec2-user/workspace/data/hana_data/elasticsearch_hana_passage.json","r", encoding="utf-8") as f:
            article_dataset = json.load(f)
            
        original_data = article_dataset["article_outputs"]
        
        inputs = {"create_data":original_data}
        response = requests.post(self.faiss_url, data = json.dumps(inputs))
        # json.dumps
        res = response  #.json()

        return_value = {"id_list":res["id_list"], 
                        "context_embedding_list":res["context_embedding_list"],
                        "title_embedding_list":res["title_embedding_list"]}
        
        print(len(res["id_list"]), len(res["context_embedding_list"]), len(res["title_embedding_list"]))
        
        return return_value
    
    def save_domain_dataset(self, id_list, context_embedding_list, title_embedding_list):
        
        with open("/home/ec2-user/workspace/data/hana_data/elasticsearch_hana_passage.json","r") as f:
            original_data = json.load(f)
             
        assert len(id_list) == len(context_embedding_list)
        assert len(id_list) == len(title_embedding_list)
        assert len(id_list) == len(original_data["article_outputs"])
        
        for original, cotext_vector, title_vector, faiss_id in zip(original_data["article_outputs"], context_embedding_list, title_embedding_list, id_list):
            original["faiss_id"] = faiss_id
            original["sub_data"][0]["article_data"][0]["context_embedding_vector"] = cotext_vector
            original["sub_data"][0]["article_data"][0]["title_embedding_vector"] = title_vector
            
        psg_outputs = {"article_outputs":original_data["article_outputs"]}
            
        file_name = f"elastic_hana_passage_v2.json"
        with open(f"/home/ec2-user/workspace/data/hana_data/{file_name}", "w", encoding='utf-8') as f:
            json.dump(psg_outputs, f, indent=4, ensure_ascii=False)
            
        return f"success to save psg json file with vector"
        
if __name__ == "__main__":
        
    create_faiss_index = CreateFaissIndex()
    filename_list = ['DB15.json', 'LD2.json', 'LD3.json', 
                    'LD4.json', 'LD5.json', 'LD6.json', 'LD9.json']
    total_passage_list = create_faiss_index.combine_data(filename_list)
    print(len(total_passage_list))
    save_data = create_faiss_index.transform_data(total_passage_list)
    print(len(save_data["article_outputs"]))
    start = time.time()
    create_status = create_faiss_index.create_faiss_index()
    end = time.time()
    print(end-start)
    save_status = create_faiss_index.save_domain_dataset(create_status["id_list"],create_status["context_embedding_list"], create_status["title_embedding_list"])
    print(save_status)
    

create_faiss_index = CreateFaissIndex()
    
    
   