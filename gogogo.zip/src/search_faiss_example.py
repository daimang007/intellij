import requests
import json

search_url = "http://0.0.0.0:9225/search"
search_data = {"question_query":["꿈 가득한 적금 지금도 가입 가능한가?"],"top_n":10}
response = requests.post(search_url, data = json.dumps(search_data))
res = response.json()
print(len(res))

for data in res:
    print(data)