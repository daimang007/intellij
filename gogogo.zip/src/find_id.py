import os
import json
import re
import requests
import openai
import faiss
import pickle
import numpy as np
import pandas as pd
from langchain.document_loaders import DataFrameLoader


class createAPI:
    def __init__(self):
        self.CONFIG_LOC = "D:\\skt\\hana-main-faiss_server\\faiss_server\\src\\config\\my-system.json"
        self.SRC_PATH = "D:\\skt\\hana-main-faiss_server\\faiss_server\\src"
        with open(self.CONFIG_LOC) as my_system_info:
            my_system_info = json.load(my_system_info)

        self.FAISS_INFO_PATH = my_system_info["PATH-INFO"]["FAISS-INFO"]
        self.INDEX_PATH_INFO = my_system_info["PATH-INFO"]["INDEX-PATH-INFO"]

        self.OPENAI_API_TYPE = my_system_info["OPENAI-INFO"]["OPENAI-API-TYPE"]
        self.OPENAI_API_BASE = my_system_info["OPENAI-INFO"]["OPENAI-API-BASE"]
        self.OPENAI_API_VERSION = my_system_info["OPENAI-INFO"]["OPENAI-API-VERSION"]
        self.OPENAI_API_KEY = my_system_info["OPENAI-INFO"]["OPENAI-API-KEY"]


        print("FAISS_INFO_PATH : " + self.FAISS_INFO_PATH)
        print("INDEX_PATH_INFO: " + self.INDEX_PATH_INFO)

        self.indexes_list = list()
        # indexes_order_dict = dict()

        with open(self.FAISS_INFO_PATH,"r") as faiss_config:
            self.FAISS_INFO = json.load(faiss_config)
            
        self.DIM = self.FAISS_INFO["DIMENSION"]
        print("DIM : " + str(self.DIM))
        print("CLIENT-INFO : " + str(len(self.FAISS_INFO['CLIENT-INFO'])))
        print("LAST-FAISS-ID : " +  str(self.FAISS_INFO["LAST-FAISS-ID"]))

        if len(self.FAISS_INFO['CLIENT-INFO']) == 0:
            print("faiss index is None")
        else:
            for idx, info in enumerate(self.FAISS_INFO['CLIENT-INFO']):
                index_file_context = os.path.join(self.INDEX_PATH_INFO, info["index_name_cotext"])
                context_index = faiss.read_index(index_file_context)
            
                self.indexes_list.append(context_index)

                # indexes_order_dict[info["domain"]] = idx


    def preprocess_data(self, text):
        pattern = r'[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ\s]'
        result = re.sub(pattern, '', str(text))
        result = result.strip()
        return result


    def save_embeddings_to_file(self, embeddings, filename):
        with open(filename, "wb") as f:
            pickle.dump(embeddings, f)

    def load_embeddings_from_file(self, filename):
        with open(filename, "rb") as f:
            embeddings = pickle.load(f)
        return embeddings


    def get_embedding(self, sentence):
        
        openai.api_type = self.OPENAI_API_TYPE
        openai.api_base = self.OPENAI_API_BASE
        openai.api_version = self.OPENAI_API_VERSION
        openai.api_key = self.OPENAI_API_KEY
        
        openAi_embeddings = openai.Embedding.create(input = [sentence], engine="text-embedding-ada-002")

        return openAi_embeddings['data'][0]['embedding']

    def create_faiss_index(self, create_df):
        
        # count passage_num
        passage_num = len(create_df)
        
        # create faiss id list
        final_faiss_id = self.FAISS_INFO["LAST-FAISS-ID"] + passage_num
        id_list = [faiss_id for faiss_id in range(self.FAISS_INFO["LAST-FAISS-ID"], final_faiss_id)]
        faiss_id_list = np.array(id_list)
        
        # create faiss embedding list
        context_embedding_vector_list = list()


        # counting = 1
        # for article in create_data:
        #     doc_title = preprocess_data(article["doc_title"])
        #     sub_title = preprocess_data(article["sub_data"][0]["sub_title"])
        #     article_title = preprocess_data(article["sub_data"][0]["article_data"][0]["article_title"])
        #     article_text = article["sub_data"][0]["article_data"][0]["article_text"]
        #     context_text = f"{doc_title} {sub_title} {article_title} {article_text}"
        #     context_embedding_vector = get_embedding(context_text)
        #     context_embedding_vector_list.append(context_embedding_vector)
        #     print(len(context_text), counting)
            
        #     title_text = f"{doc_title} {sub_title} {article_title}"
        #     title_embedding_vector = get_embedding(title_text)
        #     title_embedding_vector_list.append(title_embedding_vector)
        #     print(len(title_text), counting)
            
            # counting+=1
        
        # "TRBL_PPR_NO", "TRBL_TITL_CNTN", "TRBL_MNGM_DS_NM", "TRBL_DS_MLF_NEW_CD"
        filename = self.SRC_PATH +"\\indexes\\embeddings.pkl"
        check_file = os.path.isfile(filename)

        if check_file:
            print(" embedding_file exists ")
            context_embedding_vector_list = self.load_embeddings_from_file(filename)
        else:
            print(" embedding_file does not exist ")
            counting = 1
            for raw,column in create_df.iterrows():
                doc_no = self.preprocess_data({column[0]})
                doc_titl = self.preprocess_data({column[1]})
                doc_mngm = self.preprocess_data({column[2]})
                doc_mlf = self.preprocess_data({column[3]})

                context_text = f"{doc_no} {doc_titl} {doc_mngm} {doc_mlf}"
                context_embedding_vector = self.get_embedding(context_text)
                context_embedding_vector_list.append(context_embedding_vector)
                print(len(context_text), counting)
                # print(" context_text :" + str(counting) + " : "+ context_text)
                    
                counting+=1
            self.save_embeddings_to_file(context_embedding_vector_list, filename)
        
        print("context_embedding_vector_list : ")
        print(len(context_embedding_vector_list))

        # create_df['ID'] = id_list 
        create_df.insert(0, 'ID', id_list)
        print(id_list)
        print("create_id_with_ID : ")
        print(create_df)
        df_filename = self.SRC_PATH +"\\indexes\\df_id.pkl"
        create_df.to_pickle(df_filename)
                
        print(" passage_num :" + str(passage_num))
        

        # id = 0
        # index_dict = {}
        # for file_name in image_list:
        #     ret, sift_feature = calc_sift(sift, file_name)
        #     if ret == 0 and sift_feature.any():
        #         # record id and path
        #         index_dict.update({id: (file_name, sift_feature)})
        #         ids_list = np.linspace(ids_count, ids_count, num=sift_feature.shape[0], dtype="int64")
        #         id += 1
        #         index.add_with_ids(sift_feature, ids_list)

        faiss_context_embedding_vector_list = np.array(context_embedding_vector_list, dtype = np.float32)
        faiss_cotext_index = faiss.IndexFlatIP(faiss_context_embedding_vector_list.shape[1])
        faiss.normalize_L2(faiss_context_embedding_vector_list)
        faiss_cotext_index = faiss.IndexIDMap2(faiss_cotext_index)
        faiss_cotext_index.add_with_ids(faiss_context_embedding_vector_list, faiss_id_list)
        
    
        # index on GPU
        # res = faiss.StandardGpuResources()
        # for device_num in gpu_list:
        #     try:
        #         gpu_index_cotext = faiss.index_cpu_to_gpu(res, device_num, faiss_cotext_index)
        #         gpu_index_title = faiss.index_cpu_to_gpu(res, device_num, faiss_title_index)
        #     except:
        #         continue
        # indexes_list.append(gpu_index_cotext)
        # indexes_list.append(gpu_index_title)
        # indexes_order_dict[domain] = len(indexes_list) - 1

        # save faiss index info in file
        index_name_cotext = f"my_cotext_faiss.db"

        faiss.write_index(faiss_cotext_index, f"{self.INDEX_PATH_INFO}\\{index_name_cotext}")
        
        self.FAISS_INFO["CLIENT-INFO"].append({"index_name_cotext":index_name_cotext, "host":"localhost"})
        self.FAISS_INFO["LAST-FAISS-ID"]= final_faiss_id
        
        with open(self.FAISS_INFO_PATH,"w", encoding="utf-8") as faiss_info:
            json.dump(self.FAISS_INFO, faiss_info, indent=4, ensure_ascii=False)

        return_value = {"status":f"success to create faiss index", 
                "id_list":id_list,
                "context_embedding_list":context_embedding_vector_list}
        
        return return_value


    def search_faiss_index(self, question_query, top_n):
            
            question_query_vector = self.get_embedding(self.preprocess_data(question_query[0]))
            question_query_vector = np.array(question_query_vector, dtype = np.float32).reshape(1,self.DIM)
            faiss.normalize_L2(question_query_vector)
            search_list = list()
            for search_index in self.indexes_list:
                distances, ids = search_index.search(question_query_vector, top_n)
                for id, distance in zip(ids[0].tolist(), distances[0].tolist()):
                    data = {"faiss_id":id, "cosine_similarity":distance}
                    search_list.append(data)
                    
            search_list = sorted(search_list, key = lambda e: (-e["cosine_similarity"]))
            
            print (search_list)

            filtered_search_list = list()
            existing_ids = set()

            for item in search_list:
                faiss_id = item['faiss_id']
                if faiss_id not in existing_ids:
                    filtered_search_list.append(item)
                    existing_ids.add(faiss_id)
        
            return filtered_search_list[:top_n]

    def faiss_precise_search(embeding_library, persons, embeding_search,topk=1):
        ## 这里也可以使用上文的sklearn的包进行正则
        normalize_L2(embeding_search)
        normalize_L2(embeding_library)
        # faiss.IndexFlatIP是内积 ；faiss.indexFlatL2是欧式距离
        quantizer = faiss.IndexFlatIP(embeding_library.shape[1])
        index = quantizer
        ## 要保证输入为np.float32格式
        index.add(embeding_library.astype(np.float32))
        library = {'persons': persons, 'index': index}
        st = time.time()
        distance,idx = library['index'].search(embeding_search,topk)
        print('precise search:',time.time()-st)
        combined_results = []
        for p in range(len(distance)):
            results = [[library["persons"][i], s] for i, s in zip(idx[p], distance[p]) if s >= 0][0]
            combined_results.append(results)
        return combined_results


if __name__ == "__main__":
    create_api = createAPI()

    SRC_PATH = "D:\\skt\\hana-main-faiss_server\\faiss_server\\src"
    # Defining the columns to read
    usecols = ["TRBL_PPR_NO", "TRBL_TITL_CNTN", "TRBL_MNGM_DS_NM", "TRBL_DS_MLF_NEW_CD", "TRBL_DS_CD", "TRBL_PRST_CNTN"]
    # Read data with subset of columns
    my_data = pd.read_csv( SRC_PATH + "\\sample_007.csv", index_col="TRBL_PPR_NO", usecols=usecols,encoding="CP949")

    # print(my_data)
    # Preview first 5 rows
    # my_data.head(5)

    # df_head = my_data.head(5)
    
    # print(df_head)

    # response = create_api.create_faiss_index(my_data)
    # res = response #.json()
    # return_value = {"id_list":res["id_list"], 
    #                         "context_embedding_list":res["context_embedding_list"]}
    # print(len(res["id_list"]), len(res["context_embedding_list"]))

    # print("my_data : ")
    # print(my_data)



    search_data = {"question_query":["할인반환금조회 오류가 있는지요?"],"top_n":3}

    response = create_api.search_faiss_index("할인반환금조회 오류가 있는지요?", 3)
    res = response #.json()
    print(len(res))


    df_filename = SRC_PATH +"\\indexes\\df_id.pkl"
    loaded_df = pd.read_pickle(df_filename)
    print(loaded_df)
    print("result >>> ")
    print(response)
    for data in res:
        # print(data)
        # Filter DataFrame by ID
        result = loaded_df[loaded_df['ID'] == data['faiss_id']]
        print(result)

        


