import json
import re
import os
import openai
import faiss
import uvicorn
import argparse
import numpy as np
from fastapi import FastAPI
from pydantic import BaseModel

class FaissServerAPI:
    
    def __init__(self, config_path):
        
        # num of gpus
        self.ngpus = faiss.get_num_gpus()
        self.gpu_list = [device_num for device_num in range(self.ngpus)]
        print(f"num of gpus : {self.ngpus}")
        
        self.CONFIG_LOC = config_path
        
        with open(self.CONFIG_LOC) as hana_system_info:
            self.hana_system_info = json.load(hana_system_info)
        
        self.FAISS_INFO_PATH = self.hana_system_info["PATH-INFO"]["FAISS-INFO"]
        self.INDEX_PATH_INFO = self.hana_system_info["PATH-INFO"]["INDEX-PATH-INFO"]
        
        self.OPENAI_API_TYPE = self.hana_system_info["OPENAI-INFO"]["OPENAI-API-TYPE"]
        self.OPENAI_API_BASE = self.hana_system_info["OPENAI-INFO"]["OPENAI-API-BASE"]
        self.OPENAI_API_VERSION = self.hana_system_info["OPENAI-INFO"]["OPENAI-API-VERSION"]
        self.OPENAI_API_KEY = self.hana_system_info["OPENAI-INFO"]["OPENAI-API-KEY"]

        self.indexes_list = list()
        # self.indexes_order_dict = dict()
        
        with open(self.FAISS_INFO_PATH,"r") as faiss_config:
            self.FAISS_INFO = json.load(faiss_config)
            
        self.DIM = self.FAISS_INFO["DIMENSION"]

        if len(self.FAISS_INFO['CLIENT-INFO']) == 0:
            print("faiss index is None")
        
        else:
            for idx, info in enumerate(self.FAISS_INFO['CLIENT-INFO']):
                index_file_cotext = os.path.join(self.INDEX_PATH_INFO, info["index_name_cotext"])
                index_file_title = os.path.join(self.INDEX_PATH_INFO, info["index_name_title"])
                cotext_index = faiss.read_index(index_file_cotext)
                title_index = faiss.read_index(index_file_title)
                res = faiss.StandardGpuResources()
                for device_num in self.gpu_list:
                    try:
                        gpu_index_cotext = faiss.index_cpu_to_gpu(res, device_num, cotext_index)
                        gpu_index_title = faiss.index_cpu_to_gpu(res, device_num, title_index)
                    except:
                        continue
                self.indexes_list.append(gpu_index_cotext)
                self.indexes_list.append(gpu_index_title)
                # self.indexes_order_dict[info["domain"]] = idx
                
    def create_faiss_index(self, create_data):
        
        # count passage_num
        passage_num = len(create_data)
        
        # create faiss id list
        final_faiss_id = self.FAISS_INFO["LAST-FAISS-ID"] + passage_num
        id_list = [faiss_id
                         for faiss_id in range(self.FAISS_INFO["LAST-FAISS-ID"], final_faiss_id)]
        faiss_id_list = np.array(id_list)
        
        # create faiss embedding list
        context_embedding_vector_list = list()
        title_embedding_vector_list = list()
        counting = 1
        for article in create_data:
            doc_title = self.preprocess_data(article["doc_title"])
            sub_title = self.preprocess_data(article["sub_data"][0]["sub_title"])
            article_title = self.preprocess_data(article["sub_data"][0]["article_data"][0]["article_title"])
            article_text = article["sub_data"][0]["article_data"][0]["article_text"]
            context_text = f"{doc_title} {sub_title} {article_title} {article_text}"
            context_embedding_vector = self.get_embedding(context_text)
            context_embedding_vector_list.append(context_embedding_vector)
            print(len(context_text), counting)
            
            title_text = f"{doc_title} {sub_title} {article_title}"
            title_embedding_vector = self.get_embedding(title_text)
            title_embedding_vector_list.append(title_embedding_vector)
            print(len(title_text), counting)
            
            counting+=1
        
        faiss_context_embedding_vector_list = np.array(context_embedding_vector_list, dtype = np.float32)
        faiss_cotext_index = faiss.IndexFlatIP(faiss_context_embedding_vector_list.shape[1])
        faiss.normalize_L2(faiss_context_embedding_vector_list)
        faiss_cotext_index = faiss.IndexIDMap2(faiss_cotext_index)
        faiss_cotext_index.add_with_ids(faiss_context_embedding_vector_list, faiss_id_list)
        
        faiss_title_embedding_vector_list = np.array(title_embedding_vector_list, dtype = np.float32)
        faiss_title_index = faiss.IndexFlatIP(faiss_title_embedding_vector_list.shape[1])
        faiss.normalize_L2(faiss_title_embedding_vector_list)
        faiss_title_index = faiss.IndexIDMap2(faiss_title_index)
        faiss_title_index.add_with_ids(faiss_title_embedding_vector_list, faiss_id_list)
        
        # index on GPU
        res = faiss.StandardGpuResources()
        for device_num in self.gpu_list:
            try:
                gpu_index_cotext = faiss.index_cpu_to_gpu(res, device_num, faiss_cotext_index)
                gpu_index_title = faiss.index_cpu_to_gpu(res, device_num, faiss_title_index)
            except:
                continue
        self.indexes_list.append(gpu_index_cotext)
        self.indexes_list.append(gpu_index_title)
        # self.indexes_order_dict[domain] = len(self.indexes_list) - 1

        # save faiss index info in file
        index_name_cotext = f"hana_poc_cotext_faiss.db"
        index_name_title = f"hana_poc_title_faiss.db"
        faiss.write_index(faiss_cotext_index, f"{self.INDEX_PATH_INFO}/{index_name_cotext}")
        faiss.write_index(faiss_title_index, f"{self.INDEX_PATH_INFO}/{index_name_title}")
        
        self.FAISS_INFO["CLIENT-INFO"].append({"index_name_cotext":index_name_cotext, "index_name_title":index_name_title, "host":"localhost"})
        self.FAISS_INFO["LAST-FAISS-ID"]= final_faiss_id
        
        with open(self.FAISS_INFO_PATH,"w", encoding="utf-8") as faiss_info:
            json.dump(self.FAISS_INFO, faiss_info, indent=4, ensure_ascii=False)

        return_value = {"status":f"success to create faiss index", 
                "id_list":id_list,
                "context_embedding_list":context_embedding_vector_list,
                "title_embedding_list":title_embedding_vector_list}
        
        return return_value
    
    def search_faiss_index(self, question_query, top_n):
        
        question_query_vector = self.get_embedding(self.preprocess_data(question_query[0]))
        question_query_vector = np.array(question_query_vector, dtype = np.float32).reshape(1,self.DIM)
        faiss.normalize_L2(question_query_vector)
        search_list = list()
        for search_index in self.indexes_list:
            distances, ids = search_index.search(question_query_vector, top_n)
            for id, distance in zip(ids[0].tolist(), distances[0].tolist()):
                data = {"faiss_id":id, "cosine_similarity":distance}
                search_list.append(data)
                
        search_list = sorted(search_list, key = lambda e: (-e["cosine_similarity"]))
        
        filtered_search_list = list()
        existing_ids = set()

        for item in search_list:
            faiss_id = item['faiss_id']
            if faiss_id not in existing_ids:
                filtered_search_list.append(item)
                existing_ids.add(faiss_id)
    
        return filtered_search_list[:top_n]
    
    def get_embedding(self,sentence):
        
        openai.api_type = self.OPENAI_API_TYPE
        openai.api_base = self.OPENAI_API_BASE
        openai.api_version = self.OPENAI_API_VERSION
        openai.api_key = self.OPENAI_API_KEY
        
        openAi_embeddings = openai.Embedding.create(input = [sentence], engine="text-embedding-ada-002")
        return openAi_embeddings['data'][0]['embedding']
    
    def preprocess_data(self, text):
        pattern = r'[^a-zA-Z가-힣ㄱ-ㅎㅏ-ㅣ\s]'
        result = re.sub(pattern, '', text)
        result = result.strip()
        return result
    
class CreateInfo(BaseModel):
    create_data : list
    
class SearchInfo(BaseModel):
    question_query : list
    top_n : int
    
app = FastAPI()

@app.get('/')
def read_root():
    return {
        "result" : "This is a FAISS SERVER by using FastAPI"
    }

@app.post("/create")
def create_faiss(param : CreateInfo):
    create_status = faiss_server_excute.create_faiss_index(param.create_data)
    return create_status

@app.post("/search")
def search_faiss(param : SearchInfo):
    search_list = faiss_server_excute.search_faiss_index(param.question_query, param.top_n)
    return search_list
    
if __name__ == "__main__":
    parser = argparse.ArgumentParser(description='demo faiss server for hanabank.')
    parser.add_argument('--port', help='server port')    # 필요한 인수를 추가
    parser.add_argument('--config', help='config file path')
    args = parser.parse_args()
    faiss_server_excute = FaissServerAPI(args.config)
    uvicorn.run(app, host="0.0.0.0", port=int(args.port))
