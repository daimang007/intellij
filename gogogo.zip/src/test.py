import faiss

ngpus = faiss.get_num_gpus()
print(type(ngpus), ngpus)